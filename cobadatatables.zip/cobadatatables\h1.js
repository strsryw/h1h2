var selectJabatan = getDtOnload();
var databuffer="karyawan|505|DIV-MIS|DIV-MIS|||172|12345|TRUE|5#KP5||true|^karyawan|506|DIV-FINANCE|DIV-FINANCE|||173|12346|TRUE|5#KP6||true|^karyawan|507|DIV-GA|DIV-GA|||174|12347|TRUE|5#KP7||true|^karyawan|508|DIV-LOGISTIK|DIV-LOGISTIK|||175|12348|TRUE|5#KP8||true|^karyawan|509|DIV-MSD|DIV-MFD|||176|12349|TRUE|5#KP9||true|^karyawan|510|DIV-MDP|DIV-MDP|||177|12350|TRUE|5#KP10||true|^karyawan|511|DIV-MKT1|DIV-MKT1|||178|12351|TRUE|5#KP11||true|^karyawan|512|DIV-MKT2|DIV-MKT2|||179|12352|TRUE|5#KP12||true|^karyawan|513|DIV-MKT4|DIV-MKT4|||180|12353|TRUE|5#KP13||true|^karyawan|514|DIV-HRD|DIV-HRD|||181|12354|TRUE|5#KP14||true|^karyawan|515|DIV-INT BUSINESS|DIV-INT BUSINESS|||182|12355|TRUE|5#KP15||true|^karyawan|516|DIV-SCIENTIFIC|DIV-SCIENTIFIC|||183|12356|TRUE|5#KP16||true|^karyawan|517|DIV-PROD DEV|DIV-PROD DEV|||184|12357|TRUE|5#KP17||true|^karyawan|518|DIV-MKT5|DIV-MKT5|||185|12358|TRUE|5#KP18||true|^karyawan|519|DIV-SEKRETARIAT|DIV-SEKRETARIAT|||186|12359|TRUE|5#KP19||true|^karyawan|520|DIV-DIREKSI|DIV-DIREKSI|||187|12360|TRUE|5#KP20||true|^karyawan|521|DIV-PROCLINIC|DIV-PROCLINIC|||188|12361|TRUE|5#KP21||true|^karyawan|522|DIV-GTR|DIV-GTR|||189|12362|TRUE|5#KP22||true|^karyawan|523|DIV-TRAINING|DIV-TRAINING|||190|12363|TRUE|5#KP23||true|^karyawan|524|DIV-PROD DESIGN|DIV-PROD DESIGN|||191|12364|TRUE|5#KP24||true|^karyawan|525|DIV-REGISTRASI|DIV-REGISTRASI|||192|12365|TRUE|5#KP25||true|^karyawan|526|DIV-HR|DIV-HR|||193|12366|false|5#KP26||true|^karyawan|527|DIV-PROD MANAGEMENT|DIV-PROD MANAGEMENT|||194|12367|TRUE|5#KP27||true|^karyawan|528|DIV-LEGAL|DIV-LEGAL|||195|12368|TRUE|5#KP28||true|^karyawan|529|DIV-MARFIN|DIV-MARFIN|||196|12369|TRUE|5#KP29||true|^karyawan|530|DIV-PURCHASING|DIV-PURCHASING|||197|12370|TRUE|5#KP30||true|^karyawan|544|DIV-CORPORATE STRA|DIV-CORPORATE STRA|||198|12345|true|5#KP31||true|^karyawan|627|DIV-IRA|DIV-IRA|||208|12345|true|5#KP5||true|^karyawan|628|DIV-DR|DIV-DR|||209|12345|true|5#KP5||true|^karyawan|629|DIV-DSO|DIV-DSO|||210|12345|true|5#KP5||true|^karyawan|630|DIV-PABRIK|DIV-PABRIK|||211|12345|true|5#KP5||true|^karyawan|633|DIV-MKT3|DIV-MKT3|||213|12345|true|5#KP5||true|^karyawan|641|DIV-MKT7|DIV-MKT7|||221|12345|true|4#KP4||true|^karyawan|665|DIV-DS|DIV-DS|||229|12345|true|5#KP5||true|^";

$(document).ready(function(e){
    document.h1form.buffer.value=databuffer;
    setDataTable();
    var table = new DataTable('#example', {
        scrollX: 'true',
        columnDefs: [
            {
                target: 1,
                visible: false
            },
            {
                target: 1,
                visible: true
            }
        ]
    });
    var longpress = 500;
    var start;


    table.on('click','tbody tr td',function(e){
        $(this).attr('contenteditable','true');
        var idKaryawan = table.row(this).data()[1];
        var indexcolumn = table.cell(this).index()['column'] - 1;
    
        // if(indexcolumn == 10){
        //     var karyawan = document.getElementById('karyawan'+idKaryawan);
        //     karyawan.style.display='block';
        //     $(karyawan).select2({
        //         width: "75%"
        //     });
        // }
    })
    
    table.on('blur','tbody tr td',function(e){
        $(this).attr('contenteditable','true');
        var nilaiSesudah = $(this).text();
        var idKaryawan = table.row(this).data()[1];
        var indexcolumn = table.cell(this).index()['column'] - 1;
      
        if(indexcolumn == -1){
            //kolom untuk checkbox
        }
        else if(indexcolumn == 9){
            //data new row
            if(idKaryawan.includes('N')){
                var checkBox = document.getElementById('checkBox'+idKaryawan);
                if(checkBox.checked){
                    checkBox.value = true;
                }else{
                    checkBox.value = false;
                }
            //data yang sudah ada ketika getdata
            }else{
                var checkBox = document.getElementById('checkBox'+idKaryawan);
                if(checkBox.checked){
                    checkBox.value = true;
                }else{
                    checkBox.value = false;
                }
            }

            updateDataOnBuffer("karyawan",idKaryawan,indexcolumn,checkBox.value,document.forms[0].buffer);
        }else if(indexcolumn == 10){ // select autocomplete
            //data new row
            if (idKaryawan.includes('N')) {
                var selectKaryawan = document.getElementById('karyawan'+idKaryawan).value;
                var labelCabang = document.getElementById('cabang'+idKaryawan).innerText;
            //data yang sudah ada ketika getdata
            } else {
                var selectKaryawan = document.getElementById('karyawan'+idKaryawan).value;
                var labelCabang = document.getElementById('cabang'+idKaryawan).innerText;
           
            }
            if(selectKaryawan == 'GM'){
                updateDataOnBuffer("karyawan",idKaryawan,indexcolumn,labelCabang,document.forms[0].buffer);
            }else{
                updateDataOnBuffer("karyawan",idKaryawan,indexcolumn,selectKaryawan,document.forms[0].buffer);
            }
        }else{
            updateDataOnBuffer("karyawan",idKaryawan,indexcolumn,nilaiSesudah,document.forms[0].buffer);
        }
    })
})

function setDataTable(){
    var dataBuffer=document.h1form.buffer.value;
    var splitBuffer1=dataBuffer.split('^');
        var txtData = '';
        var n= 1;
        var lastValue;
        splitBuffer1.forEach(function(item) {
            var itemData = item.split('|'); //length 13
            // console.log(itemData);
            if (itemData.length >= 11) {
                // console.log(itemData[11]);
                txtData += `<tr>
                    <td>
                        <input type="checkbox" id="selectRow${itemData[1]}"      name="selectRow" value='${itemData[1]}' onclick="onlyOne(this)">
                    </td>
                    <td>${itemData[1]}</td>
                    <td>${itemData[2]}</td>
                    <td>${itemData[3]}</td>
                    <td>${itemData[4]}</td>
                    <td>${itemData[5]}</td>
                    <td>${itemData[6]}</td>
                    <td>${itemData[7]}</td>
                    <td>${itemData[8]}</td>
                    <td>${itemData[9]}</td>
                    <td>${itemData[10]}
                        <input type="checkbox" id="checkBox${itemData[1]}" name="checkBox">
                    </td>
                    <td>
                    <label id ='cabang${itemData[1]}' >${itemData[11]}</label>
                    <select class='select2' name="karyawan" id="karyawan${itemData[1]}">
                        <option value="SATRIO">SATRIO</option>
                        <option value="RIZKI">RIZKI</option>
                        <option value="BAGUS">BAGUS</option>
                    </select>
                    </td>
                    
                </tr>`;
                //dapatkan last id
                lastValue = itemData[1]; //belum berguna
                n++;
            }
            
        });
        //tampung
        document.getElementById('lastIdTable').value = lastValue;
        $("#example").children("tbody:first").html(txtData);
        $('.select2').select2({
                width: "75%"
            });
          var selectKaryawan = document.getElementsByName('karyawan');
          for(let i = 0; i < selectKaryawan.length;i++){
            selectKaryawan[i].innerHTML = selectJabatan;
          }
}

function addData(){
    $("#example").DataTable().page('last').draw('page');
    tambahRecord();
}

function tambahRecord(){ 
    var lastIdTable = document.getElementById('lastIdTable').value;
	lastId=document.forms[0].lastId.value;
	if (lastId.length==0){
		document.forms[0].lastId.value='0';
        lastIdTable = parseInt(lastIdTable)+1;
        document.getElementById('lastIdTable').value = lastIdTable;
	}
	else{
		lastId=parseInt(lastId)+1;
		document.forms[0].lastId.value=lastId;
        lastIdTable = parseInt(lastIdTable)+1;
        document.getElementById('lastIdTable').value = lastIdTable;
	}
	lastId=document.forms[0].lastId.value;	
    var select = `<label id ='cabangN${lastId}' >true</label>
    <select class='select2' name="karyawan" id="karyawanN${lastId}">
    </select>`;

    var checkbox = `<input type="checkbox" id="checkBoxN${lastId}" name="checkBox">`;
    const table = new DataTable('#example');
	table.row
        .add(['',
            'N'+lastId,
            'Masukkan inputan',
            'Masukkan inputan',
            'Masukkan inputan',
            'Masukkan inputan',
            'Masukkan inputan',
            'Masukkan inputan',
            'Masukkan inputan',
            'Masukkan inputan',
            checkbox,
            select
        ])
        .draw(false);
    document.getElementById('karyawanN'+lastId).innerHTML = selectJabatan;
    $('.select2').select2({
        width: "75%"
      });
	newRow="karyawan|N"+lastId+"||||||12345|true||||^";
	document.forms[0].buffer.value=document.forms[0].buffer.value+newRow;
}

//onchange rowSelected menambahkan tanda biru ketika selected 
function rowSelected(id){
    var selectRow = document.getElementById('selectRow' + id);
    if (selectRow.checked === true) {
        // Mendapatkan referensi ke elemen <tr> terkait (contoh: parent dari checkbox)
        var trElement = selectRow.closest('tr');
        if (trElement) {
            // Menambahkan atau menghapus kelas 'selected' dari elemen <tr>
            trElement.classList.add('selected');
            document.getElementById('karyawan'+id).style.color = 'black';
        }
    }else if(selectRow.checked === false){
        var trElement = selectRow.closest('tr');
        if (trElement) {
            // Menambahkan atau menghapus kelas 'selected' dari elemen <tr>
            trElement.classList.remove('selected');
        }
    }
}

function delData(){
    // get value checkbox
    // var checkboxes = getValues('selectRow');
    var id = getValues('selectRow');
    //get tr yang ada class selected nya
    var selected = document.getElementsByClassName('selected');
    selected[0].style.display='none';
    //delete untuk sekaligus banyak
    // for(let i = 0; i<checkboxes.length;i++){
    //     //hapus row atau record yang ada di table sementara sebelum disave
    //     selected[i].style.display = 'none';
    //     //tambah - pada id id  yang ingin dihapus
    //     deleteDataOnBuffer("karyawan",checkboxes[i],document.forms[0].buffer);	  
    // }
    deleteDataOnBuffer("karyawan",id,document.forms[0].buffer);
}

//get value checkbox
function getValues(name) {
    var checkboxes = document.getElementsByName(name);
    var values = [];
    checkboxes.forEach(function (checkbox) {
      if (checkbox.checked) {
        values.push(checkbox.value);
      }
    });
    return values;
}

//get select value 
function getDtOnload(){ 
    var url = 'h2.php';
    var dataCallback;
        $.ajax({
            url: url,
            type: "POST",
            data:{mode:'getDtOnload'},
            dataType:"text",
            async:false,
            success: function(result){
            // console.log(result);return
            dataCallback=result;
        }
    });	
    return dataCallback; 
}

//onclick checkbox agar hanya 1 yang dapat dicentang
function onlyOne(checkbox) {
    var checkboxes = document.getElementsByName('selectRow');
    checkboxes.forEach((item) => {
        if (item !== checkbox) {
            item.checked = false; // Menghapus cek dari checkbox lain
            var trElement = item.closest('tr'); // Dapatkan elemen <tr> terkait
            if (trElement) {
                trElement.classList.remove('selected'); // Hapus kelas 'selected' dari elemen <tr>
            }
        }
    });
    // Memeriksa status checkbox saat ini
    if (checkbox.checked) {
        // Checkbox saat ini dicentang, tambahkan kelas 'selected' pada elemen <tr> terkait
        var trElement = checkbox.closest('tr');
        if (trElement) {
            trElement.classList.add('selected'); // Tambahkan kelas 'selected' ke elemen <tr>
        }
    } else {
        // Checkbox saat ini tidak dicentang, hapus kelas 'selected' dari elemen <tr> terkait
        var trElement = checkbox.closest('tr');
        if (trElement) {
            trElement.classList.remove('selected'); // Hapus kelas 'selected' dari elemen <tr>
        }
    }
}

//html
//jika dibutuhkan
// onchange="rowSelected('${itemData[1]}')"
// console.log(table.cell(this).index()['column'])
// console.log('clicked: ' + table.row(this).data()[1])