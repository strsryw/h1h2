function gridFindmenu(grid,descriptionRecorderColumn,descriptionRecorderColumn_1) {
	if((gridGroupUser.getSelectedRows().length)<1 ){ alert("Silahkan Pilih User"); return;}
	this.finder = menu_finder();
	this.callerType="grid";
	this.grid = grid;
	
	//this.idRecorderColumn = idRecorderColumn;
	this.descriptionRecorderColumn = descriptionRecorderColumn;	
	this.descriptionRecorderColumn_1=descriptionRecorderColumn_1;
}
function menu_finder() {

	var obj_calwindow = window.open(
		'cariGroupAsset.php','Menu',		'resizable=0,scrollbars=0,toolbar=0,directories=0,status=1,menubar=0,width=265,height=320,left=430,top=250'
	);
	obj_calwindow.opener = self;
	obj_calwindow.focus();
}

function gridFindjenis(grid,descriptionRecorderColumn,descriptionRecorderColumn_1) {
	if((gridMenu.getSelectedRows().length)<1 ){ alert("Silahkan Pilih Kategori Asset"); return;}
	
	this.finder = jenis_finder();
	this.callerType="grid";
	this.grid = grid;
	
	//this.idRecorderColumn = idRecorderColumn;
	this.descriptionRecorderColumn = descriptionRecorderColumn;	
	this.descriptionRecorderColumn_1=descriptionRecorderColumn_1;
}
function jenis_finder() {

	var obj_calwindow = window.open(
		'cariKategoriAsset.php','jenis',		'resizable=0,scrollbars=0,toolbar=0,directories=0,status=1,menubar=0,width=300,height=400,left=600,top=150'
	);
	obj_calwindow.opener = self;
	obj_calwindow.focus();
}
